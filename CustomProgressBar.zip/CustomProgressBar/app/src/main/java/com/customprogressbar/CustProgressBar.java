package com.customprogressbar;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.widget.ProgressBar;

/**
 * Created by RCHINTA on 9/30/2017.
 */

public class CustProgressBar extends ProgressBar {

    private static final int DEFAULT_COLOR = 0XFFFC00D1;
    private static final int DEFAULT_COLOR_UNREACHED_COLOR = 0xFFd3d6da;
    private static final int DEFAULT_HEIGHT_REACHED_PROGRESS_BAR = 2;
    private static final int DEFAULT_HEIGHT_UNREACHED_PROGRESS_BAR = 2;
    private static final int DEFAULT_BEND_OFFSET = 3;

    /**
     * view width except padding
     */
    protected int mRealWidth;

    /**
     * painter of all drawing things
     */
    protected Paint mPaintProgress = new Paint();
    protected Paint mPaintBackground = new Paint();

    private int mReachedBarColor;
    private int mUnReachedBarColor;

    private int mReachedProgressBarHeight = dp2px(DEFAULT_HEIGHT_REACHED_PROGRESS_BAR);
    private int mUnReachedProgressBarHeight = dp2px(DEFAULT_HEIGHT_UNREACHED_PROGRESS_BAR);

    private int mBendOffset = dp2px(DEFAULT_BEND_OFFSET);

    private Path mPath = new Path();

    public CustProgressBar(Context context) {
        super(context);
    }

    public CustProgressBar(Context context, AttributeSet attrs) {
        this(context, attrs,0);
    }

    public CustProgressBar(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        obtainStyledAttributes(attrs);

        mPaintProgress.setAntiAlias(true);
        mPaintProgress.setColor(mUnReachedBarColor);
        mPaintProgress.setStyle(Paint.Style.FILL);
        mPaintProgress.setStrokeJoin(Paint.Join.ROUND);

        mPaintBackground.setAntiAlias(true);
        mPaintBackground.setColor(mReachedBarColor);
        mPaintBackground.setStyle(Paint.Style.FILL);
        mPaintBackground.setStrokeJoin(Paint.Join.ROUND);
    }

    /**
     * get the styled attributes
     *
     * @param attrs
     */
    private void obtainStyledAttributes(AttributeSet attrs)
    {
        // init values from custom attributes
        final TypedArray attributes = getContext().obtainStyledAttributes(
                attrs, R.styleable.CustProgressBar);


        mReachedBarColor = attributes
                .getColor(
                        R.styleable.CustProgressBar_progress_reached_color,
                        DEFAULT_COLOR);
        mUnReachedBarColor = attributes
                .getColor(
                        R.styleable.CustProgressBar_progress_unreached_color,
                        DEFAULT_COLOR_UNREACHED_COLOR);
        mReachedProgressBarHeight = (int) attributes
                .getDimension(
                        R.styleable.CustProgressBar_progress_reached_bar_height,
                        mReachedProgressBarHeight);
        mUnReachedProgressBarHeight = (int) attributes
                .getDimension(
                        R.styleable.CustProgressBar_progress_unreached_bar_height,
                        mUnReachedProgressBarHeight);

        mBendOffset = (int) attributes
                .getDimension(
                        R.styleable.CustProgressBar_progress_end_bend_offset,
                        mBendOffset);

        attributes.recycle();
    }

    @Override
    protected synchronized void onMeasure(int widthMeasureSpec,
                                          int heightMeasureSpec)
    {
        int width = MeasureSpec.getSize(widthMeasureSpec);
        int height = MeasureSpec.getSize(heightMeasureSpec);
        setMeasuredDimension(width, height);

        mRealWidth = getMeasuredWidth() - getPaddingRight() - getPaddingLeft();
    }



    @Override
    protected synchronized void onDraw(Canvas canvas) {
        canvas.save();
        canvas.translate(getPaddingLeft(), 0);

        float radio = getProgress() * 1.0f / getMax();
        float progressPosX = (int) ((mRealWidth + mBendOffset) * radio);


        if(progressPosX > (mRealWidth + mBendOffset)){
            progressPosX = mRealWidth + mBendOffset;
        }

        mPath.reset();
        mPath.moveTo(0,0);
        mPath.lineTo(mRealWidth,0);
        mPath.lineTo(mRealWidth,getHeight());
        mPath.lineTo(0,getHeight());
        mPath.lineTo(0,0);
        canvas.drawPath(mPath, mPaintBackground);

        mPath.reset();
        mPath.moveTo(0,0);
        mPath.lineTo(Math.min(progressPosX,mRealWidth),0);
        mPath.lineTo(Math.min(progressPosX-(progressPosX == (mRealWidth + mBendOffset) ? 0 : mBendOffset), mRealWidth),getHeight());
        mPath.lineTo(0,getHeight());
        mPath.lineTo(0,0);
        canvas.drawPath(mPath, mPaintProgress);

        canvas.restore();
    }

    /**
     * dp 2 px
     *
     * @param dpVal
     */
    protected int dp2px(int dpVal)
    {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,
                dpVal, getResources().getDisplayMetrics());
    }

}
