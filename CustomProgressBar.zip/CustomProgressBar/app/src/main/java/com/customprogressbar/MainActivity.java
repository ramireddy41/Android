package com.customprogressbar;

import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    private static final int MSG_PROGRESS_UPDATE = 0x110;

    private CustProgressBar mProgressBar;
    private CustProgressBarParallel mProgressBarParallel;
    private Handler mHandler = new Handler() {
        public void handleMessage(android.os.Message msg) {
            int progress = mProgressBar.getProgress();
            mProgressBar.setProgress(++progress);
            progress = mProgressBarParallel.getProgress();
            mProgressBarParallel.setProgress(++progress);
            if (progress >= 100) {
                mHandler.removeMessages(MSG_PROGRESS_UPDATE);
            }
            mHandler.sendEmptyMessageDelayed(MSG_PROGRESS_UPDATE, 100);
        };
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mProgressBar = (CustProgressBar) findViewById(R.id.custPb);
        mProgressBarParallel = (CustProgressBarParallel) findViewById(R.id.custPbParallel);
        mHandler.sendEmptyMessage(MSG_PROGRESS_UPDATE);

    }
}
