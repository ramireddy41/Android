package coin.assign;

import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.coin.assign.R;
import coin.assign.retrofit.info.Item;
import java.util.List;

public class CryptoListInfoAdapter extends RecyclerView.Adapter<CryptoListInfoAdapter.ViewHolder> {

    private List<Item> mData;
    private ItemClickListener mClickListener;
    Context context;

    // data is passed into the constructor
    CryptoListInfoAdapter(List<Item> data) {
        this.mData = data;
    }

    // Usually involves inflating a layout from XML and returning the holder
    // inflates the row layout from xml when needed
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.crypto_list_item_info, parent, false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    // Involves populating data into the item through holder
    // binds the data to the TextView in each row
    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        // Get the data model based on position
        Item data = mData.get(position);
        if(data != null) {
            // Set item views based on your views and data model
            TextView name = holder.name;
            name.setText(data.getName());

            ImageView logo = holder.logo;
            RequestOptions options = new RequestOptions()
                .centerCrop()
                .placeholder(R.mipmap.ic_launcher_round)
                .error(R.mipmap.ic_launcher_round);

            Glide.with(context).load(data.getLogo()).apply(options).into(logo);

            TextView websiteURL = holder.websiteURL;
            websiteURL.setText(data.getUrls().getWebsite()[0]);

            TextView technicalDocURL = holder.technicalDocURL;
            technicalDocURL.setText(data.getUrls().getTechnical_doc()[0]);
        }

    }

    // Returns the total count of items in the list
    // total number of rows
    @Override
    public int getItemCount() {
        return mData.size();
    }

    // Provide a direct reference to each of the views within a data item
    // Used to cache the views within the item layout for fast access
    // stores and recycles views as they are scrolled off screen
    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        // Your holder should contain a member variable
        // for any view that will be set as you render a row
        TextView name;
        ImageView logo;
        TextView websiteURL;
        TextView technicalDocURL;
        TextView description;

        // We also create a constructor that accepts the entire item row
        // and does the view lookups to find each subview
        ViewHolder(View itemView) {
            // Stores the itemView in a public final member variable that can be used
            // to access the context from any ViewHolder instance.
            super(itemView);

            name = itemView.findViewById(R.id.name);
            logo = itemView.findViewById(R.id.logo);
            websiteURL = itemView.findViewById(R.id.websiteURL);
            technicalDocURL = itemView.findViewById(R.id.technicalDocURL);
            description = itemView.findViewById(R.id.description);

            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            if (mClickListener != null) mClickListener.onItemClick(view, getAdapterPosition());
        }
    }

    // convenience method for getting data at click position
    Item getItem(int id) {
        return mData.get(id);
    }

    // allows clicks events to be caught
    void setClickListener(ItemClickListener itemClickListener) {
        this.mClickListener = itemClickListener;
    }

    // parent activity will implement this method to respond to click events
    public interface ItemClickListener {
        void onItemClick(View view, int position);
    }
}