package coin.assign.retrofit.info;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Urls {

  public String[] website;

  public String[] twitter;

  public String[] message_board;

  public String[] chat;

  public String[] reddit;

  public String[] explorer;

  public String[] technical_doc;

  public String[] source_code;

  public String[] announcement;

  public String[] getWebsite ()
  {
    return website;
  }

  public void setWebsite (String[] website)
  {
    this.website = website;
  }

  public String[] getTwitter ()
  {
    return twitter;
  }

  public void setTwitter (String[] twitter)
  {
    this.twitter = twitter;
  }

  public String[] getMessage_board ()
  {
    return message_board;
  }

  public void setMessage_board (String[] message_board)
  {
    this.message_board = message_board;
  }

  public String[] getChat ()
  {
    return chat;
  }

  public void setChat (String[] chat)
  {
    this.chat = chat;
  }

  public String[] getReddit ()
  {
    return reddit;
  }

  public void setReddit (String[] reddit)
  {
    this.reddit = reddit;
  }

  public String[] getExplorer ()
  {
    return explorer;
  }

  public void setExplorer (String[] explorer)
  {
    this.explorer = explorer;
  }

  public String[] getTechnical_doc ()
  {
    return technical_doc;
  }

  public void setTechnical_doc (String[] technical_doc)
  {
    this.technical_doc = technical_doc;
  }

  public String[] getSource_code ()
  {
    return source_code;
  }

  public void setSource_code (String[] source_code)
  {
    this.source_code = source_code;
  }

  public String[] getAnnouncement ()
  {
    return announcement;
  }

  public void setAnnouncement (String[] announcement)
  {
    this.announcement = announcement;
  }

  @Override
  public String toString()
  {
    return "ClassPojo [website = "+website+", twitter = "+twitter+", message_board = "+message_board+", chat = "+chat+", reddit = "+reddit+", explorer = "+explorer+", technical_doc = "+technical_doc+", source_code = "+source_code+", announcement = "+announcement+"]";
  }
}
