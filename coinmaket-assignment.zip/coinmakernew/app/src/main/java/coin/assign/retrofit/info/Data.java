package coin.assign.retrofit.info;

import java.util.HashMap;

public class Data
{
    public Item item;


    public Data() {
        this.item = new Item();
    }
}