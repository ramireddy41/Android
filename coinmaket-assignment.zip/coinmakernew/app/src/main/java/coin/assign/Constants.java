package coin.assign;

public class Constants {

  public static String id;
}
