package coin.assign;

import android.os.Bundle;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import coin.assign.retrofit.CryptoList;
import coin.assign.retrofit.Datum;
import coin.assign.retrofit.info.Data;
import coin.assign.retrofit.info.Item;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.coin.assign.R;
import java.util.ArrayList;
import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class InformationScreen extends AppCompatActivity {

    APIInterface apiInterface;
    TextView name;
    ImageView logo;
    TextView websiteURL;
    TextView technicalDocURL;
    TextView description;
    Data data;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.crypto_list_item_info);

        name = findViewById(R.id.name);
        logo = findViewById(R.id.logo);
        websiteURL = findViewById(R.id.websiteURL);
        technicalDocURL = findViewById(R.id.technicalDocURL);
        description = findViewById(R.id.description);

        Datum datum = (Datum) getIntent().getSerializableExtra("coin");

        apiInterface = APIClient.getClient(datum.getId().toString()).create(APIInterface.class);

        getInfo(datum.getId().toString());
    }

    private void getInfo(String info) {
        Call<coin.assign.retrofit.info.CryptoListInfo> call2 = apiInterface.doGetInfo(info);
        call2.enqueue(new Callback<coin.assign.retrofit.info.CryptoListInfo>() {
            @Override
            public void onResponse(Call<coin.assign.retrofit.info.CryptoListInfo> call, Response<coin.assign.retrofit.info.CryptoListInfo> response) {
                coin.assign.retrofit.info.CryptoListInfo list = response.body();
                if(list.getData() != null) {
                    final Item item = list.getData().item;

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (item != null) {
                                name.setText("Name: " + item.getName() + " \n Logo:");
                                RequestOptions options = new RequestOptions()
                                    .centerCrop()
                                    .placeholder(R.mipmap.ic_launcher_round)
                                    .error(R.mipmap.ic_launcher_round);
                                Glide.with(InformationScreen.this).load(item.getLogo())
                                    .apply(options)
                                    .into(logo);

                                if (item.getUrls().getWebsite() != null
                                    && item.getUrls().getWebsite().length > 0) {
                                    String websiteUrl = item.getUrls().getWebsite()[0];
                                    if (websiteUrl != null) {
                                        websiteURL.setClickable(true);
                                        websiteURL
                                            .setMovementMethod(LinkMovementMethod.getInstance());
                                        websiteURL
                                            .setText(Html.fromHtml(item.getUrls().getWebsite()[0]));
                                    }
                                }

                                if (item.getUrls().getTechnical_doc() != null
                                    && item.getUrls().getTechnical_doc().length > 0) {
                                    String techDocUrl = item.getUrls().getTechnical_doc()[0];
                                    if (techDocUrl != null) {
                                        technicalDocURL.setClickable(true);
                                        technicalDocURL
                                            .setMovementMethod(LinkMovementMethod.getInstance());
                                        technicalDocURL
                                            .setText(
                                                Html.fromHtml(
                                                    item.getUrls().getTechnical_doc()[0]));
                                    }
                                }
                                description.setText(("\n Description: \n" + item.description));
                            }
                        }
                    });
                }
            }

            @Override
            public void onFailure(Call<coin.assign.retrofit.info.CryptoListInfo> call, Throwable t) {
                Toast.makeText(InformationScreen.this, "onFailure", Toast.LENGTH_SHORT).show();
                Log.d("XXXX", t.getLocalizedMessage());
                call.cancel();
            }
        });
    }



}
