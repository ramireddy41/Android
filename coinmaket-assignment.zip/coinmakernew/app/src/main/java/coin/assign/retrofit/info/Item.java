package coin.assign.retrofit.info;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import java.io.Serializable;

public class Item implements Serializable
{

    @SerializedName("symbol")
    public String symbol;

    @SerializedName("date_added")
    public String date_added;

    @SerializedName("urls")
    public Urls urls;

    @SerializedName("name")
    public String name;

    @SerializedName("logo")
    public String logo;

    @SerializedName("description")
    public String description;

    @SerializedName("id")
    public String id;

    @SerializedName("category")
    public String category;

    @SerializedName("slug")
    public String slug;

    @SerializedName("platform")
    public String platform;

    @SerializedName("notice")
    public String notice;

    @SerializedName("tags")
    public String[] tags;

    public String getSymbol ()
    {
        return symbol;
    }

    public void setSymbol (String symbol)
    {
        this.symbol = symbol;
    }

    public String getDate_added ()
    {
        return date_added;
    }

    public void setDate_added (String date_added)
    {
        this.date_added = date_added;
    }

    public Urls getUrls ()
    {
        return urls;
    }

    public void setUrls (Urls urls)
    {
        this.urls = urls;
    }

    public String getName ()
    {
        return name;
    }

    public void setName (String name)
    {
        this.name = name;
    }

    public String getLogo ()
    {
        return logo;
    }

    public void setLogo (String logo)
    {
        this.logo = logo;
    }

    public String getDescription ()
    {
        return description;
    }

    public void setDescription (String description)
    {
        this.description = description;
    }

    public String getId ()
    {
        return id;
    }

    public void setId (String id)
    {
        this.id = id;
    }

    public String getCategory ()
    {
        return category;
    }

    public void setCategory (String category)
    {
        this.category = category;
    }

    public String getSlug ()
    {
        return slug;
    }

    public void setSlug (String slug)
    {
        this.slug = slug;
    }

    public String getPlatform ()
{
    return platform;
}

    public void setPlatform (String platform)
    {
        this.platform = platform;
    }

    public String getNotice ()
    {
    return notice;
    }

    public void setNotice (String notice)
    {
        this.notice = notice;
    }

    public String[] getTags ()
    {
        return tags;
    }

    public void setTags (String[] tags)
    {
        this.tags = tags;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [symbol = "+symbol+", date_added = "+date_added+", urls = "+urls+", name = "+name+", logo = "+logo+", description = "+description+", id = "+id+", category = "+category+", slug = "+slug+", platform = "+platform+", notice = "+notice+", tags = "+tags+"]";
    }

}